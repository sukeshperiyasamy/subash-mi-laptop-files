//Technical Tamizha
//HC-05 BT controll

void setup() {
  // put your setup code here, to run once:
pinMode(2,OUTPUT);
Serial.begin(9600);
}

void loop() {
  // put your main code here, to run repeatedly:
char in = (char)Serial.read();

if(in == 'A'){
  digitalWrite(2,HIGH);
  Serial.print(in);
}

else if(in == 'B'){
  digitalWrite(2,LOW);
  Serial.begin(in);
  
}
}
