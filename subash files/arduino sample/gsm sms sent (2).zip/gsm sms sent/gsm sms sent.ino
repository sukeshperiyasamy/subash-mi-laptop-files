//#include <SoftwareSerial.h>
//SoftwareSerial mySerial(9, 10);

void setup()
{
  Serial.begin(9600);   // Setting the baud rate of GSM Module  
  Serial.begin(9600);    // Setting the baud rate of Serial Monitor (Arduino)
  delay(100);
}

void loop()
{
//delay(10000);   //Give enough time for GSM to register on Network
  
  Serial.println("AT+CMGF=1");    //Sets the GSM Module in Text Mode
  delay(1000);  // Delay of 1000 milli seconds or 1 second
  Serial.println("AT+CMGS=\"+919042249014\"\r");// Replace x with mobile number
  delay(1000);
  Serial.println(" sample ku unoda number potu test panra atha unku message varthu . ");// The SMS text you want to send
  delay(100);
  Serial.println((char)26);// ASCII code of CTRL+Z
  delay(1000);

   while(1);  //Wait forever
}
