#include <Servo.h>
Servo motor;
int pos= 0;

void setup() {
    // put your setup code here, to run once:
  motor.attach(9); //You can change the servo pin

}

void loop() {
  
    for(pos =0; pos <=90; pos += 1){ //you can change the possition(pos)value[pos=Servo rotating Degree]
      motor.write(pos);
      delay(2);  //delay time (servo rotating speed)
    }
  
    for(pos =90; pos >= 0; pos -= 1){ 
      motor.write(pos);
      delay(2);
    }

   
}
